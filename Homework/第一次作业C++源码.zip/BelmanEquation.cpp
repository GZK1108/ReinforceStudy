#include <iostream>
#include <iomanip>
#include <vector>
#include <Eigen/Dense>  // ��������
using namespace std;

const int GRID_ROW = 5;  // ��������
const int GRID_COL = 5;  //��������
const int NUM_STATES = GRID_ROW * GRID_COL;  // ״̬����
const int BORDER = -1;  // Խ��ͷ�
const int FORBIDDEN = -1;  //�����ͷ�
const int TARGET = 1;  //Ŀ�꽱��
const int OTHERSTEP = 0; //���߽硢������Ŀ���⣬�����ط��Ļر�
const double gamma = 0.9;  // �ۿ�����
const double alpha = 1.0e-6;  //��������ֵ

// ���嶯�����
enum Action { RIGHT = 0, DOWN = 1, UP = 2, LEFT = 3, STAY = 4 };

// ��������ṹ
vector<int> grid = {
    OTHERSTEP, OTHERSTEP, OTHERSTEP, OTHERSTEP, OTHERSTEP,
    OTHERSTEP, FORBIDDEN, FORBIDDEN, OTHERSTEP, OTHERSTEP,
    OTHERSTEP, OTHERSTEP, FORBIDDEN, OTHERSTEP, OTHERSTEP,
    OTHERSTEP, FORBIDDEN, TARGET,    FORBIDDEN, OTHERSTEP,
    OTHERSTEP, FORBIDDEN, OTHERSTEP, OTHERSTEP, OTHERSTEP
};

// ��ʼ�����Ա�
/*
//policy 1��2
vector<int> policy = {
    RIGHT, RIGHT, RIGHT, RIGHT, DOWN,  
    UP, UP, RIGHT, RIGHT, DOWN,        
    UP, LEFT, DOWN, RIGHT, DOWN,    
    UP, RIGHT, STAY, LEFT, DOWN,       
    UP, RIGHT, UP, LEFT, LEFT              
};

//policy 3
vector<int> policy = {
	RIGHT, RIGHT, RIGHT, RIGHT, RIGHT,  
	RIGHT, RIGHT, RIGHT, RIGHT, RIGHT,   
	RIGHT, RIGHT, RIGHT, RIGHT, RIGHT,  
	RIGHT, RIGHT, RIGHT, RIGHT, RIGHT,     
	RIGHT, RIGHT, RIGHT, RIGHT, RIGHT           
};*/

//policy 4
vector<int> policy = {
    RIGHT, LEFT, LEFT, UP, UP,
    DOWN,  STAY, RIGHT,DOWN,RIGHT,
    LEFT,  RIGHT,DOWN, LEFT,STAY,
    STAY,  DOWN, UP,   UP,  RIGHT,
    STAY,  RIGHT,STAY, RIGHT,STAY
};



//��ͼ����
void draw_grid(const vector<int>& policy) {
    for (int i = 0; i < GRID_ROW; ++i) {
        for (int j = 0; j < GRID_COL; ++j) {
            int s = i * GRID_COL + j;
            switch (policy[s]) {
            case UP: cout << " �� "; break;
            case DOWN: cout << " �� "; break;
            case LEFT: cout << " �� "; break;
            case RIGHT: cout << " �� "; break;
            case STAY: cout << "  S "; break;
            default: break;
            }

        }
        std::cout << std::endl;
    }
}


// ״̬ת�ƺ����ͽ�������
int next_state(int state, int action, double& reward) {
    int row = state / GRID_ROW;
    int col = state % GRID_COL;

    switch (action) {
    case UP:
        if (row > 0) {
            reward += grid[state - GRID_COL];
            return state - GRID_COL;
        }
        reward += BORDER;  // Խ��ͷ�
        return state;
    case DOWN:
        if (row < GRID_ROW - 1) {
            reward += grid[state + GRID_COL];
            return state + GRID_COL;
        }
        reward += BORDER;
        return state;
    case LEFT:
        if (col > 0) {
            reward += grid[state - 1];
            return state - 1;
        }
        reward += BORDER;
        return state;
    case RIGHT:
        if (col < GRID_COL - 1) {
            reward += grid[state + 1];
            return state + 1;
        }
        reward += BORDER;
        return state;
    case STAY:
        reward += grid[state];
        return state;
    default:
        return state;
    }
}


// ����״̬ת�ƾ���P�ͽ�������R
void construct_matrices(const std::vector<int>& policy, Eigen::MatrixXd& P, Eigen::VectorXd& R) {
    for (int s = 0; s < NUM_STATES; ++s) {
        double reward = 0;
        int s_next = next_state(s, policy[s], reward);
        P(s, s_next) = 1.0;
        R(s) = reward;
        
    }
}


//���������
void value_iteration(const Eigen::MatrixXd& P, const Eigen::VectorXd& R, Eigen::VectorXd& V) {
    Eigen::VectorXd V_new(NUM_STATES);
    while (true) {
		V_new = R + gamma * P * V;

        if ((V_new - V).norm() < alpha) {
            break;
        }
        V = V_new;
    }
}



int main() {
    
    draw_grid(policy);
    // ��ʼ���������� R ��״̬ת�ƾ��� P
    Eigen::VectorXd R(NUM_STATES);
    Eigen::MatrixXd P = Eigen::MatrixXd::Zero(NUM_STATES, NUM_STATES);

    // ����
    construct_matrices(policy, P, R);


    // ���� (I - gamma P) ����
    Eigen::MatrixXd I = Eigen::MatrixXd::Identity(NUM_STATES, NUM_STATES);
    Eigen::MatrixXd A = I - gamma * P;

    // V = (I - gamma P)' * R
    Eigen::VectorXd V = A.inverse() * R;

    // ���V
    cout << "Closed-form Solution:" << endl;
    for (int i = 0; i < NUM_STATES; i++) {
		cout << std::left<< setw(5) <<fixed << setprecision(1)<< V(i) << " ";
        if ((i + 1) % GRID_COL == 0) {
            cout << endl;
        }
    }
    //������
    Eigen::VectorXd Vr = Eigen::VectorXd::Zero(NUM_STATES);
	value_iteration(P, R, Vr);

    //���
    cout << "Iterative Solution:" << endl;
	for (int i = 0; i < NUM_STATES; i++) {
        cout << std::left<< setw(5)  << fixed << setprecision(1) << Vr(i) << " ";
		if ((i + 1) % GRID_COL == 0) {
			cout << endl;
		}
	}

    return 0;
}
